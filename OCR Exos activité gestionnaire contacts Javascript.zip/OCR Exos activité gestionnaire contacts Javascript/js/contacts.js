//Activité : gestion des contacts
//création de la classe Contact :
class Contact {constructor(prenom, nom) {this.prenom=prenom; 
										 this.nom=nom}
			   decrire() {return(`Nom : ${this.nom}, prénom : ${this.prenom}`)}
			  }
//création des 2 premiers contacts :
const caroleLevisse = new Contact ("Carole", "Lévisse");
const melodieNelsonne = new Contact ("Mélodie", "Nelsonne");
//tableau des contacts :
const tableContacts = [caroleLevisse, melodieNelsonne];
//fonction affichage du tableau
function afficherTableau () {for (let i=0; i<tableContacts.length; i++) {console.log(tableContacts[i].decrire());}
							}
//affichage du message de bienvenue :
console.log("Bienvenue dans le gestionnaire des contacts !\n1 : Lister les contacts\n2 : Ajouter un contact\n0 : Quitter");
//pop-up pour le choix de l'action à réaliser
let choix= prompt("Choisissez une option :");
//boucle de choix tant que l'utilisateur ne choisit pas de quitter
while (choix!=="0") {if (choix==="1") {console.log("Voici la liste de tous vos contacts :");
									   afficherTableau();
									  }
					else {if (choix==="2") {let nouveauNom= prompt("Entrez le nom du nouveau contact :");
									  		let nouveauPrenom= prompt("Entrez le prénom du nouveau contact :");
									  		let nouveauContact = new Contact (nouveauPrenom, nouveauNom);
									  		tableContacts.push(nouveauContact);
									  		console.log("Le nouveau contact a été ajouté.");
									  		}
					 	 else {console.log("Cette entrée est invalide.");}
						 }
					console.log("1 : Lister les contacts\n2 : Ajouter un contact\n0 : Quitter");
					choix= prompt("Choisissez une option :");
					}
//sortie de la boucle si l'utilisateur choisit 0				
console.log("Au revoir !");
